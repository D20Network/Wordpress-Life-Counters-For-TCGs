<?php
/**
 * Plugin Name: TTRPG & Wargame Dice Roller
 * Description: A versatile dice roller for tabletop games and wargames.
 * Version: 1.0
 * Author: Void, Corp
 * License: GPL2
 */

function dice_roller_enqueue_scripts() {
    wp_enqueue_style('dice-roller-css', plugin_dir_url(__FILE__) . 'dice-roller.css');
    wp_enqueue_script('dice-roller-js', plugin_dir_url(__FILE__) . 'dice-roller.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'dice_roller_enqueue_scripts');

function dice_roller_shortcode() {
    ob_start();
    ?>
    <div class="dice-roller-container">
        <h1>Fantasy Dice Roller</h1>
        <div class="single-die-container">
            <h2>Roll a Single Die</h2>
            <select id="single-die-select">
                <option value="2">d2</option>
                <option value="4">d4</option>
                <option value="6">d6</option>
                <option value="8">d8</option>
                <option value="10">d10</option>
                <option value="12">d12</option>
                <option value="20">d20</option>
                <option value="100">d100</option>
            </select>
            <button id="roll-single-die">Roll</button>
            <div id="single-die-result"></div>
        </div>
        <div class="multi-die-container">
            <h2>Roll Multiple Dice</h2>
            <input type="text" id="multi-die-input" placeholder="e.g., 3d6+2">
            <button id="roll-multi-die">Roll</button>
            <div id="multi-die-result"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('dice_roller', 'dice_roller_shortcode');
?>
