<?php
/*
Plugin Name: Game Timer
Description: A custom WordPress plugin for a timer with stopwatch and countdown functionalities.
Version: 1.0
Author: Void, Corp
*/

// Register and enqueue styles and scripts
function fantasy_timer_enqueue_scripts() {
    wp_enqueue_style('fantasy-timer-style', plugins_url('assets/css/style.css', __FILE__));
    wp_enqueue_script('fantasy-timer-script', plugins_url('assets/js/script.js', __FILE__), array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'fantasy_timer_enqueue_scripts');

// Shortcode handler for embedding the timer
function fantasy_timer_shortcode($atts) {
    ob_start();
    ?>
    <div class="fantasy-timer">
        <h2>Fantasy Timer</h2>
        <div class="timer-controls">
            <button id="startStop">Start</button>
            <input type="text" id="countdownTime" placeholder="Enter countdown time (in seconds)">
            <button id="startCountdown">Start Countdown</button>
        </div>
        <div class="timer-display">
            <p id="timerDisplay">00:00:00</p>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('fantasy_timer', 'fantasy_timer_shortcode');
