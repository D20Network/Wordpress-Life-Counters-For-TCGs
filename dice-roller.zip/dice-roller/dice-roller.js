jQuery(document).ready(function($) {
    function rollDie(sides) {
        return Math.floor(Math.random() * sides) + 1;
    }

    function parseDiceNotation(notation) {
        let matches = notation.match(/(\d+)d(\d+)([+-]\d+)?/);
        if (!matches) return null;
        return {
            rolls: parseInt(matches[1]),
            sides: parseInt(matches[2]),
            modifier: matches[3] ? parseInt(matches[3]) : 0
        };
    }

    $('#roll-single-die').click(function() {
        let sides = parseInt($('#single-die-select').val());
        let result = rollDie(sides);
        $('#single-die-result').text(`Result: ${result}`);
    });

    $('#roll-multi-die').click(function() {
        let input = $('#multi-die-input').val().trim();
        let dice = parseDiceNotation(input);
        if (!dice) {
            $('#multi-die-result').text('Invalid input');
            return;
        }
        let total = dice.modifier;
        for (let i = 0; i < dice.rolls; i++) {
            total += rollDie(dice.sides);
        }
        $('#multi-die-result').text(`Result: ${total}`);
    });
});
