jQuery(document).ready(function($) {
    var timer; // Variable to hold the timer interval
    var startTime; // Variable to store start time
    var countdownInterval; // Variable to hold countdown interval

    // Start/Stop button click handler
    $('#startStop').click(function() {
        if ($(this).text() === 'Start') {
            startTimer();
            $(this).text('Stop');
        } else {
            stopTimer();
            $(this).text('Start');
        }
    });

    // Start countdown button click handler
    $('#startCountdown').click(function() {
        var countdownTime = $('#countdownTime').val();
        startCountdown(countdownTime);
    });

    // Function to start the stopwatch
    function startTimer() {
        startTime = Date.now();
        timer = setInterval(updateTimer, 1000); // Update timer every second
    }

    // Function to stop the stopwatch
    function stopTimer() {
        clearInterval(timer);
    }

    // Function to update the stopwatch display
    function updateTimer() {
        var elapsedTime = Math.floor((Date.now() - startTime) / 1000); // Elapsed time in seconds
        var hours = Math.floor(elapsedTime / 3600);
        var minutes = Math.floor((elapsedTime % 3600) / 60);
        var seconds = elapsedTime % 60;
        $('#timerDisplay').text(formatTime(hours) + ':' + formatTime(minutes) + ':' + formatTime(seconds));
    }

    // Function to format time values (add leading zeros)
    function formatTime(time) {
        return time < 10 ? '0' + time : time;
    }

    // Function to start the countdown
    function startCountdown(countdownTime) {
        var endTime = Date.now() + (countdownTime * 1000); // Calculate end time
        countdownInterval = setInterval(function() {
            var remainingTime = Math.floor((endTime - Date.now()) / 1000); // Remaining time in seconds
            if (remainingTime <= 0) {
                clearInterval(countdownInterval);
                $('#timerDisplay').text('Countdown Complete!');
            } else {
                var hours = Math.floor(remainingTime / 3600);
                var minutes = Math.floor((remainingTime % 3600) / 60);
                var seconds = remainingTime % 60;
                $('#timerDisplay').text(formatTime(hours) + ':' + formatTime(minutes) + ':' + formatTime(seconds));
            }
        }, 1000); // Update countdown every second
    }
});
